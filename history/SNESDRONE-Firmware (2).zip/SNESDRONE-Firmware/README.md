# SNESDRONE_FW
Firmware for the STM32 processor on the SNESDRONE board.
